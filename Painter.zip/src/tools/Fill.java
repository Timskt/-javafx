package tools;

public class Fill extends Tool {

    public Fill() {

    }

    @Override
    public void using(double x, double y) {
        graphicsContext.fillRect(x, y, 15, 15);
    }

    @Override
    public void addStartPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addPathPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addEndPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void draw() {

    }

    @Override
    public boolean complete() {
        return true;
    }
}
