package tools;

import graphics.Pixel;
import javafx.scene.Cursor;

import java.util.Scanner;

public class Text extends Tool {

    private Pixel pixel = new Pixel(0, 0);
    private String s = "";

    private void setText() {

    }

    @Override
    public void using(double x, double y) {
        Scanner input = new Scanner(System.in);
        s = input.nextLine();
        graphicsContext.strokeText(s, pixel.getX(), pixel.getY(), x - pixel.getX());
    }

    @Override
    public void addStartPoints(double x, double y) {
        graphicsContext.getCanvas().setCursor(Cursor.TEXT);
        pixel.setX(x);
        pixel.setY(y);
    }

    @Override
    public void addPathPoints(double x, double y) {

    }

    @Override
    public void addEndPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void draw() {

    }

    @Override
    public boolean complete() {
        return true;
    }
}
