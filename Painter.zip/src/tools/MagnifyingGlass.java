package tools;

import javafx.scene.SnapshotParameters;
import javafx.scene.image.Image;

public class MagnifyingGlass extends Tool {

    private static int times = 0;

    public MagnifyingGlass() {

    }

    @Override
    public void using(double x, double y) {

    }

    @Override
    public void addStartPoints(double x, double y) {
        if (times <= 4) {
            Image image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
            graphicsContext.getCanvas().setWidth(graphicsContext.getCanvas().getWidth() * 1.2);
            graphicsContext.getCanvas().setHeight(graphicsContext.getCanvas().getHeight() * 1.2);
            super.renovate(image);
            times++;
        }
    }

    @Override
    public void addPathPoints(double x, double y) {

    }

    @Override
    public void addEndPoints(double x, double y) {

    }

    @Override
    public void draw() {

    }

    @Override
    public boolean complete() {
        return true;
    }
}
