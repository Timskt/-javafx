package tools;

import javafx.scene.SnapshotParameters;

public class ColorPicker extends Tool {

    public ColorPicker() {
    }

    @Override
    public void using(double x, double y) {
        graphicsContext.setStroke(graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null).getPixelReader().getColor((int) x, (int) y));
    }

    @Override
    public void addStartPoints(double x, double y) {

    }

    @Override
    public void addPathPoints(double x, double y) {

    }

    @Override
    public void addEndPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void draw() {
    }

    @Override
    public boolean complete() {
        return true;
    }
}
