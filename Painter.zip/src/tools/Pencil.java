package tools;

import graphics.Pixel;

public class Pencil extends Tool {

    Pixel pixel = new Pixel();

    public Pencil() {

    }

    @Override
    public void using(double x, double y) {
        graphicsContext.strokeLine(x, y, x, y);
    }

    @Override
    public void addStartPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addPathPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addEndPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void draw() {

    }

    @Override
    public boolean complete() {
        return true;
    }
}
