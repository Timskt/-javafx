package tools;

import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

public class Eraser extends Tool {

    public Eraser() {
    }

    @Override
    public void using(double x, double y) {
        Paint fill = graphicsContext.getFill();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(x, y, 10, 10);
        graphicsContext.setFill(fill);
    }

    @Override
    public void addStartPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addPathPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void addEndPoints(double x, double y) {
        using(x, y);
    }

    @Override
    public void draw() {

    }

    @Override
    public boolean complete() {
        return true;
    }
}
