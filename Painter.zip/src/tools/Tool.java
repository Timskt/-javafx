package tools;

import canvas.SelectContent;
import javafx.scene.Cursor;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

public abstract class Tool implements Editable {
    /**
     * 此类为工具类，实现了Editable接口，同时为所有绘制工具的父类
     * 抽象类
     * using方法为使用工具进行绘制的方法
     */

    protected GraphicsContext graphicsContext;

    public Tool() {

    }

    @Override
    public void mouseMoved(double x, double y) {

    }

    @Override
    public void setGraphicsContext(GraphicsContext graphicsContext) {
        this.graphicsContext = graphicsContext;
        graphicsContext.getCanvas().setCursor(Cursor.CROSSHAIR);
    }

    protected void renovate(Image image) {
        Paint fill = graphicsContext.getFill();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, graphicsContext.getCanvas().getWidth(), graphicsContext.getCanvas().getHeight());
        graphicsContext.setFill(fill);
        graphicsContext.drawImage(image, 0, 0);
    }

    public abstract void using(double x, double y);

    @Override
    public SelectContent getContent() {
        return null;
    }
}
