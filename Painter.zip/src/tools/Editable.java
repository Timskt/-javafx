package tools;

import canvas.SelectContent;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public interface Editable {
    /**
     * 此接口为绘制接口，方法有：添加起始（鼠标点击）坐标、路径（鼠标拖动）坐标、结尾（鼠标释放）坐标、
     * 绘制以及设置graphicsContext参数等等
     * 对图像进行编辑的类都必须实现此接口，由PainterController进行调用
     *
     * @param x
     * @param y
     */

    void mouseMoved(double x, double y);

    void addStartPoints(double x, double y);

    void addPathPoints(double x, double y);

    void addEndPoints(double x, double y);

    void draw();

    void setGraphicsContext(GraphicsContext graphicsContext);

    boolean complete();

    SelectContent getContent();

}
