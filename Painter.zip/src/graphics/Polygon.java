package graphics;

import javafx.scene.SnapshotParameters;

public class Polygon extends Graphics {

    private boolean start;
    private Pixel firstPixel = new Pixel();

    public Polygon() {
        start = false;
    }

    private boolean isClose() {
        if (Math.pow(endPixel.getX() - firstPixel.getX(), 2) + Math.pow(endPixel.getY() - firstPixel.getY(), 2) <= 100) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void addStartPoints(double x, double y) {
        if (start == false) {
            start = true;
            startPixel.setX(x);
            startPixel.setY(y);
            firstPixel.setX(x);
            firstPixel.setY(y);
        } else {
            startPixel.setX(endPixel.getX());
            startPixel.setY(endPixel.getY());
        }
        image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
    }

    @Override
    public void addEndPoints(double x, double y) {
        endPixel.setX(x);
        endPixel.setY(y);
    }

    @Override
    public void show() {
        if (start == true && isClose()) {
            start = false;
            graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), firstPixel.getX(), firstPixel.getY());
            firstPixel = new Pixel();
        } else {
            graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
        }
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), x, y);
    }
}
