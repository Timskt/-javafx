package graphics;

public class Rhombic extends Graphics {

    private Pixel top = new Pixel();
    private Pixel bottom = new Pixel();
    private Pixel midLeft = new Pixel();
    private Pixel midRight = new Pixel();

    public Rhombic() {

    }

    private void setPixels(double x, double y, double x1, double y1) {
        top.setX((x1 - x) / 2.0 + x);
        top.setY(y);
        bottom.setX((x1 - x) / 2.0 + x);
        bottom.setY(y1);
        midLeft.setX(x);
        midLeft.setY((y1 - y) / 2.0 + y);
        midRight.setX(x1);
        midRight.setY((y1 - y) / 2.0 + y);
    }

    private void drawRhombic() {
        graphicsContext.strokeLine(top.getX(), top.getY(), midLeft.getX(), midLeft.getY());
        graphicsContext.strokeLine(top.getX(), top.getY(), midRight.getX(), midRight.getY());
        graphicsContext.strokeLine(midLeft.getX(), midLeft.getY(), bottom.getX(), bottom.getY());
        graphicsContext.strokeLine(midRight.getX(), midRight.getY(), bottom.getX(), bottom.getY());
    }

    @Override
    public void show() {
        setDrawRect();
        setPixels(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
        drawRhombic();
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        setPixels(_x, _y, x, y);
        super.showRect(_x, _y, x, y);
        drawRhombic();
    }
}
