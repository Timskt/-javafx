package graphics;

public class IsoscelesTriangle extends Graphics {

    public IsoscelesTriangle() {

    }

    @Override
    public void show() {
        double width;
        setDrawRect();
        width = endPixel.getX() - startPixel.getX();
        graphicsContext.strokeLine(startPixel.getX() + width / 2.0, startPixel.getY(), startPixel.getX(), endPixel.getY());
        graphicsContext.strokeLine(startPixel.getX(), endPixel.getY(), endPixel.getX(), endPixel.getY());
        graphicsContext.strokeLine(startPixel.getX() + width / 2.0, startPixel.getY(), endPixel.getX(), endPixel.getY());
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        super.showRect(_x, _y, x, y);
        graphicsContext.strokeLine(_x + (x - _x) / 2.0, _y, _x, y);
        graphicsContext.strokeLine(_x, y, x, y);
        graphicsContext.strokeLine(_x + (x - _x) / 2.0, _y, x, y);
    }
}
