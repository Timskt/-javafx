package graphics;

public class Rectangle extends Graphics {

    private Pixel upperLeft = new Pixel();

    public Rectangle() {

    }

    @Override
    public void show() {
        double width, height;
        setDrawRect();
        upperLeft.setX(startPixel.getX());
        upperLeft.setY(startPixel.getY());
        width = endPixel.getX() - startPixel.getX();
        height = endPixel.getY() - startPixel.getY();
        graphicsContext.strokeRect(upperLeft.getX(), upperLeft.getY(), width, height);
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        super.showRect(_x, _y, x, y);
        graphicsContext.strokeRect(_x, _y, x - _x, y - _y);
    }
}
