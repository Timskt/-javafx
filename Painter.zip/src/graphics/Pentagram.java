package graphics;

public class Pentagram extends Graphics {

    private Pixel top = new Pixel();
    private Pixel left = new Pixel();
    private Pixel right = new Pixel();
    private Pixel bottomLeft = new Pixel();
    private Pixel bottomRight = new Pixel();

    public Pentagram() {

    }

    private void setPixels(double x, double y, double x1, double y1) {
        double width = x1 - x;
        double height = y1 - y;
        top.setX(x + width / 2.0);
        top.setY(y);
        left.setX(x);
        left.setY(y + height / 3.0);
        right.setX(x1);
        right.setY(y + height / 3.0);
        bottomLeft.setX(x + width / 6.0);
        bottomLeft.setY(y1);
        bottomRight.setX(x + width * 5.0 / 6.0);
        bottomRight.setY(y1);
    }

    private void drawPentagram() {
        graphicsContext.strokeLine(top.getX(), top.getY(), bottomLeft.getX(), bottomLeft.getY());
        graphicsContext.strokeLine(top.getX(), top.getY(), bottomRight.getX(), bottomRight.getY());
        graphicsContext.strokeLine(left.getX(), left.getY(), bottomRight.getX(), bottomRight.getY());
        graphicsContext.strokeLine(right.getX(), right.getY(), bottomLeft.getX(), bottomLeft.getY());
        graphicsContext.strokeLine(left.getX(), left.getY(), right.getX(), right.getY());
    }

    @Override
    public void show() {
        setDrawRect();
        setPixels(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
        drawPentagram();
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        setPixels(_x, _y, x, y);
        super.showRect(_x, _y, x, y);
        drawPentagram();
    }
}
