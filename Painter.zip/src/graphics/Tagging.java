package graphics;

import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

public class Tagging extends Graphics {

    private Pixel upperLeft = new Pixel();

    public Tagging() {

    }

    private void drawTagging(double x, double y, double x1, double y1) {
        double width, height, arcWidth, arcHeight;
        upperLeft.setX(x);
        upperLeft.setY(y);
        width = x1 - x;
        height = y1 - y;
        arcWidth = width / 4.0;
        arcHeight = height / 4.0;
        graphicsContext.strokeRoundRect(upperLeft.getX(), upperLeft.getY(), width, height * 5 / 6, arcWidth, arcHeight);
        Paint contextStroke = graphicsContext.getStroke();
        graphicsContext.setStroke(Color.WHITE);
        graphicsContext.strokeLine(x + arcWidth,
                y + height * 5 / 6,
                x + arcWidth * 2,
                y + height * 5 / 6);
        graphicsContext.setStroke(contextStroke);
        graphicsContext.strokeLine(x + arcWidth,
                y + height * 5 / 6,
                x + arcWidth * 3 / 2,
                y1);
        graphicsContext.strokeLine(x + arcWidth * 2,
                y + height * 5 / 6,
                x + arcWidth * 3 / 2,
                y1);
    }

    @Override
    public void show() {
        setDrawRect();
        drawTagging(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        super.showRect(_x, _y, x, y);
        drawTagging(_x, _y, x, y);
    }
}
