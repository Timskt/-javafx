package graphics;

import javafx.scene.shape.ArcType;

public class Arc extends Graphics {

    private Pixel coordinate = new Pixel();
    private double startAngle = -30;
    private double arcExtent = 120;
    private ArcType closure = ArcType.ROUND;

    public Arc() {

    }

    @Override
    public void show() {
        double width, height;
        setDrawRect();
        coordinate.setX(startPixel.getX());
        coordinate.setY(startPixel.getY());
        width = endPixel.getX() - startPixel.getX();
        height = endPixel.getY() - startPixel.getY();
        graphicsContext.strokeArc(coordinate.getX(), coordinate.getY(), width, height, startAngle, arcExtent, closure);
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        super.showRect(_x, _y, x, y);
        graphicsContext.strokeArc(_x, _y, x - _x, y - _y, startAngle, arcExtent, closure);
    }
}
