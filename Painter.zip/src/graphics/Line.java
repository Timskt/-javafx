package graphics;

public class Line extends Graphics {

    public Line() {

    }

    @Override
    public void show() {
        graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), x, y);
    }

}
