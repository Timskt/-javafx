package graphics;

import canvas.SelectContent;
import javafx.scene.Cursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import tools.Editable;

public abstract class Graphics implements Editable {
    /**
     * 图形类，用于在画板上画不同的图形，实现Editable接口
     * 该类为所有图形类的父类
     * 抽象类
     * startPixel和endPixel为图形绘制的矩形区域的坐上角坐标和右下角坐标，同时也是鼠标点击和释放时的坐标
     * graphicsContext来自于controllers包的PainterController类
     * image为绘制图形前画板的图像内容，用于刷新图像
     * 该类实现的绘制过程为：鼠标点击，获取坐标，鼠标拖动，显示不同位置图形的大小形状，鼠标释放，刷新图像，获取位置绘制最终的图形内容
     */
    protected Pixel startPixel = new Pixel(0.0, 0.0);
    protected Pixel endPixel = new Pixel(0.0, 0.0);
    protected GraphicsContext graphicsContext;
    protected Image image;

    public Graphics() {

    }

    protected void renovate() {
        Paint fill = graphicsContext.getFill();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, graphicsContext.getCanvas().getWidth(), graphicsContext.getCanvas().getHeight());
        graphicsContext.setFill(fill);
        graphicsContext.drawImage(image, 0, 0);
    }

    public abstract void show();

    protected void setDrawRect() {
        if (startPixel.getX() > endPixel.getX() && startPixel.getY() > endPixel.getY()) {
            double tempX = startPixel.getX();
            double tempY = startPixel.getY();
            startPixel.setX(endPixel.getX());
            endPixel.setX(tempX);
            startPixel.setY(endPixel.getY());
            endPixel.setY(tempY);
        } else if (startPixel.getX() > endPixel.getX()) {
            double tempX = startPixel.getX();
            startPixel.setX(endPixel.getX());
            endPixel.setX(tempX);
        } else if (startPixel.getY() > endPixel.getY()) {
            double tempY = startPixel.getY();
            startPixel.setY(endPixel.getY());
            endPixel.setY(tempY);
        }
    }

    protected void showRect(double x, double y, double x1, double y1) {
        Paint stroke = graphicsContext.getStroke();
        graphicsContext.setStroke(Color.BLACK);
        boolean show = true;
        for (double i = x; i < x1; i += (x1 - x) / 20) {
            if (show) {
                graphicsContext.strokeLine(i, y, (i + (x1 - x) / 10 > x1 ? x1 : i + (x1 - x) / 20), y);
            }
            show = !show;
        }
        for (double i = y; i < y1; i += (y1 - y) / 10) {
            if (show) {
                graphicsContext.strokeLine(x, i, x, (i + (y1 - y) / 10 > y1 ? y1 : i + (y1 - y) / 20));
            }
            show = !show;
        }
        for (double i = x; i < x1; i += (x1 - x) / 10) {
            if (show) {
                graphicsContext.strokeLine(i, y1, (i + (x1 - x) / 10 > x1 ? x1 : i + (x1 - x) / 20), y1);
            }
            show = !show;
        }
        for (double i = y; i < y1; i += (y1 - y) / 10) {
            if (show) {
                graphicsContext.strokeLine(x1, i, x1, (i + (y1 - y) / 10 > y1 ? y1 : i + (y1 - y) / 20));
            }
            show = !show;
        }
        graphicsContext.setStroke(stroke);
    }

    @Override
    public void addStartPoints(double x, double y) {
        startPixel.setX(x);
        startPixel.setY(y);
        image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
    }

    @Override
    public void addEndPoints(double x, double y) {
        endPixel.setX(x);
        endPixel.setY(y);
    }

    @Override
    public void draw() {
        renovate();
        show();
    }

    @Override
    public void mouseMoved(double x, double y) {

    }

    @Override
    public void setGraphicsContext(GraphicsContext graphicsContext) {
        this.graphicsContext = graphicsContext;
        graphicsContext.getCanvas().setCursor(Cursor.CROSSHAIR);
    }

    @Override
    public boolean complete() {
        return true;
    }

    @Override
    public SelectContent getContent() {
        return null;
    }
}