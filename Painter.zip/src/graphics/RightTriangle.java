package graphics;

public class RightTriangle extends Graphics {

    public RightTriangle() {

    }

    @Override
    public void show() {
        setDrawRect();
        graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), endPixel.getX(), endPixel.getY());
        graphicsContext.strokeLine(startPixel.getX(), startPixel.getY(), startPixel.getX(), endPixel.getY());
        graphicsContext.strokeLine(startPixel.getX(), endPixel.getY(), endPixel.getX(), endPixel.getY());
    }

    @Override
    public void addPathPoints(double x, double y) {
        super.renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        super.showRect(_x, _y, x, y);
        graphicsContext.strokeLine(_x, _y, x, y);
        graphicsContext.strokeLine(_x, _y, _x, y);
        graphicsContext.strokeLine(_x, y, x, y);
    }
}
