package canvas;

import graphics.Pixel;
import javafx.scene.Cursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import tools.Editable;

public class Selector implements Editable {

    private WritableImage selectedContent = null;
    private Image image;
    private GraphicsContext graphicsContext;
    private Pixel startPixel;
    private Pixel endPixel;

    public Selector() {
        startPixel = new Pixel(0.0, 0.0);
        endPixel = new Pixel(0.0, 0.0);
    }

    @Override
    public void mouseMoved(double x, double y) {

    }

    @Override
    public void addStartPoints(double x, double y) {
        startPixel.setX(x);
        startPixel.setY(y);
        selectedContent = null;
    }

    @Override
    public void addPathPoints(double x, double y) {
        renovate();
        double _x = startPixel.getX();
        double _y = startPixel.getY();
        if (_x > x && _y > y) {
            double tempX = _x;
            double tempY = _y;
            _x = x;
            x = tempX;
            _y = y;
            y = tempY;
        } else if (_x > x) {
            double tempX = _x;
            _x = x;
            x = tempX;
        } else if (_y > y) {
            double tempY = _y;
            _y = y;
            y = tempY;
        }
        showSelected(_x, _y, x, y);
    }

    @Override
    public void addEndPoints(double x, double y) {
        endPixel.setX(x);
        endPixel.setY(y);
    }

    private void renovate() {
        Paint fill = graphicsContext.getFill();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, graphicsContext.getCanvas().getWidth(), graphicsContext.getCanvas().getHeight());
        graphicsContext.setFill(fill);
        graphicsContext.drawImage(image, 0, 0);
    }


    private void showSelected(double x, double y, double x1, double y1) {
        Paint stroke = graphicsContext.getStroke();
        graphicsContext.setStroke(Color.BLACK);
        boolean show = true;
        for (double i = x; i < x1; i += (x1 - x) / 20) {
            if (show) {
                graphicsContext.strokeLine(i, y, (i + (x1 - x) / 10 > x1 ? x1 : i + (x1 - x) / 20), y);
            }
            show = !show;
        }
        for (double i = y; i < y1; i += (y1 - y) / 10) {
            if (show) {
                graphicsContext.strokeLine(x, i, x, (i + (y1 - y) / 10 > y1 ? y1 : i + (y1 - y) / 20));
            }
            show = !show;
        }
        for (double i = x; i < x1; i += (x1 - x) / 10) {
            if (show) {
                graphicsContext.strokeLine(i, y1, (i + (x1 - x) / 10 > x1 ? x1 : i + (x1 - x) / 20), y1);
            }
            show = !show;
        }
        for (double i = y; i < y1; i += (y1 - y) / 10) {
            if (show) {
                graphicsContext.strokeLine(x1, i, x1, (i + (y1 - y) / 10 > y1 ? y1 : i + (y1 - y) / 20));
            }
            show = !show;
        }
        graphicsContext.setStroke(stroke);
    }

    private void setDrawRect() {
        if (startPixel.getX() > endPixel.getX() && startPixel.getY() > endPixel.getY()) {
            double tempX = startPixel.getX();
            double tempY = startPixel.getY();
            startPixel.setX(endPixel.getX());
            endPixel.setX(tempX);
            startPixel.setY(endPixel.getY());
            endPixel.setY(tempY);
        } else if (startPixel.getX() > endPixel.getX()) {
            double tempX = startPixel.getX();
            startPixel.setX(endPixel.getX());
            endPixel.setX(tempX);
        } else if (startPixel.getY() > endPixel.getY()) {
            double tempY = startPixel.getY();
            startPixel.setY(endPixel.getY());
            endPixel.setY(tempY);
        }
    }

    @Override
    public void draw() {
        setDrawRect();
        if (endPixel.getX() != startPixel.getX() && endPixel.getY() != startPixel.getY()) {
            selectedContent = new WritableImage((int) (endPixel.getX() - startPixel.getX()), (int) (endPixel.getY() - startPixel.getY()));
            for (int i = 0; i < selectedContent.getWidth(); i++) {
                for (int j = 0; j < selectedContent.getHeight(); j++) {
                    selectedContent.getPixelWriter().setColor(i, j, image.getPixelReader().getColor((int) (startPixel.getX() + i), (int) (startPixel.getY() + j)));
                }
            }
        }
    }

    @Override
    public void setGraphicsContext(GraphicsContext graphicsContext) {
        this.graphicsContext = graphicsContext;
        image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
        graphicsContext.getCanvas().setCursor(Cursor.CROSSHAIR);
    }

    @Override
    public boolean complete() {
        return false;
    }

    @Override
    public SelectContent getContent() {
        if (selectedContent != null) {
            return new SelectContent(selectedContent,
                    startPixel.getX(),
                    startPixel.getY(),
                    endPixel.getX() - startPixel.getX(),
                    endPixel.getY() - startPixel.getY());
        }
        return null;
    }
}
