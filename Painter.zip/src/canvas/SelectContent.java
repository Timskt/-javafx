package canvas;

import graphics.Pixel;
import javafx.scene.image.Image;

public class SelectContent {
    private Image content = null;
    private Pixel upperLeft;
    private double width;
    private double height;

    public SelectContent() {
        content = null;
        upperLeft = new Pixel(0, 0);
        width = 0.0;
        height = 0.0;
    }

    public SelectContent(Image content, double startX, double startY, double width, double height) {
        this.content = content;
        this.upperLeft = new Pixel(startX, startY);
        this.width = width;
        this.height = height;
    }

    public Image getContent() {
        return content;
    }

    public void setContent(Image content) {
        this.content = content;
    }

    public Pixel getUpperLeft() {
        return this.upperLeft;
    }

    public double getWidth() {
        return this.width;
    }

    public double getHeight() {
        return this.height;
    }
}
