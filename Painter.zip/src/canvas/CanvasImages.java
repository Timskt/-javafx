package canvas;

import javafx.scene.image.Image;

import java.util.LinkedList;

public class CanvasImages {
    /**
     * 此类为实现画板图像撤销、重绘的类
     */

    //以下两个list集合用于存储编辑图像的记录，方便进行撤销、重绘操作
    private LinkedList<Image> imageList = new LinkedList<Image>();
    private LinkedList<Image> imageRecovery = new LinkedList<Image>();


    public void addCanvasImage(Image image) {
        imageList.addLast(image);
    }

    public Image getNowCanvasImage() {
        if (imageList.size() > 0) {
            return imageList.getLast();
        } else {
            return null;
        }
    }

    public Image getBackward() {
        imageRecovery.addLast(imageList.removeLast());
        return (imageList.size() > 0) ? imageList.getLast() : null;
    }

    public Image getForward() {
        imageList.addLast(imageRecovery.removeLast());
        return imageList.getLast();
    }

    public boolean isForward() {
        return imageRecovery.size() > 0;
    }

    public boolean isBackward() {
        return imageList.size() > 0;
    }
}
