package canvas;

import javafx.scene.Cursor;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import tools.Editable;

public class Paste implements Editable {

    private Image image;
    private Image content;
    private GraphicsContext graphicsContext;

    public Paste(Image content) {
        this.content = content;
    }

    private void showContent(double x, double y) {
        if (content != null) {
            graphicsContext.drawImage(content, x - content.getWidth() / 2.0, y - content.getHeight() / 2.0);
        }
    }

    @Override
    public void mouseMoved(double x, double y) {
        renovate();
        showContent(x, y);
    }

    @Override
    public void addStartPoints(double x, double y) {
        renovate();
        showContent(x, y);
    }

    @Override
    public void addPathPoints(double x, double y) {
        renovate();
        showContent(x, y);
    }

    @Override
    public void addEndPoints(double x, double y) {
        renovate();
        showContent(x, y);
        content = null;
        image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
    }

    private void renovate() {
        Paint fill = graphicsContext.getFill();
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, graphicsContext.getCanvas().getWidth(), graphicsContext.getCanvas().getHeight());
        graphicsContext.setFill(fill);
        graphicsContext.drawImage(image, 0, 0);
    }

    @Override
    public void draw() {

    }

    @Override
    public void setGraphicsContext(GraphicsContext graphicsContext) {
        this.graphicsContext = graphicsContext;
        image = graphicsContext.getCanvas().snapshot(new SnapshotParameters(), null);
        graphicsContext.getCanvas().setCursor(Cursor.CROSSHAIR);
    }

    @Override
    public boolean complete() {
        return true;
    }

    @Override
    public SelectContent getContent() {
        return null;
    }
}
