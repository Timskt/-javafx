package controllers;

import XMLs.XMLAdminister;
import canvas.CanvasImages;
import canvas.Paste;
import canvas.SelectContent;
import canvas.Selector;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import main.Main;
import tools.Editable;
import tools.Pencil;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.LinkedList;
import java.util.ResourceBundle;

public class PainterController implements Initializable {
    /**
     * 绘画界面控制类，该类主要用于处理用户在绘制界面做进行的操作，包括图形图像编辑处理、文件保存、退出程序等等
     */

    @FXML
    public MenuBar menuBar;
    @FXML
    public Button stageHide;
    @FXML
    public Canvas canvas;
    @FXML
    public ColorPicker color1;
    @FXML
    public ColorPicker color2;
    @FXML
    public Text pixelText;
    @FXML
    public Button backward;
    @FXML
    public Button forward;
    @FXML
    public Slider thickness;
    @FXML
    public Text graphicsSizeText;
    @FXML
    public Text canvasSizeText;
    @FXML
    public Slider canvasSize;
    @FXML
    public CheckBox invert;
    @FXML
    public Button darker;
    @FXML
    public Button brighter;
    @FXML
    public Button saturate;
    @FXML
    public Button desaturate;
    @FXML
    public Button paste;
    @FXML
    public Button cut;
    @FXML
    public Button copy;

    private Image image;
    private GraphicsContext graphicsContext;
    private Editable editor;
    private CanvasImages canvasImages = new CanvasImages();
    private double width;
    private double height;
    private SelectContent selectContent = new SelectContent();
    private Image pasteContent = null;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        initColor();
        try {
            initCanvas();
        } catch (Exception e) {
            System.out.println("画板加载失败");
        }
        initEditor();
        initAssemblies();
    }

    private void initEditor() {
        editor = new Pencil();
        editor.setGraphicsContext(graphicsContext);
    }

    private void initAssemblies() {
        forward.setDisable(true);
        backward.setDisable(true);
        paste.setDisable(true);
        copy.setDisable(true);
        cut.setDisable(true);
        thickness.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number old_ov, Number new_ov) {
                graphicsContext.setLineWidth((Double) new_ov / 10.0);
            }
        });
        canvasSize.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number old_ov, Number new_ov) {
                if (new_ov != old_ov) {
                    width = canvas.getWidth() * ((Double) new_ov / (Double) old_ov);
                    height = canvas.getHeight() * ((Double) new_ov / (Double) old_ov);
                    canvas.setWidth(width);
                    canvas.setHeight(height);
                    renovate();
                    canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
                }
            }
        });
        darker.setOnAction(e -> {
            adjustBrightness(true);
        });
        brighter.setOnAction(e -> {
            adjustBrightness(false);
        });
        saturate.setOnAction(e -> {
            adjustSaturate(true);
        });
        desaturate.setOnAction(e -> {
            adjustSaturate(false);
        });
        invert.selectedProperty().addListener(new ChangeListener<Boolean>() {
            @Override
            public void changed(ObservableValue<? extends Boolean> observableValue, Boolean aBoolean, Boolean t1) {
                if (t1 != aBoolean) {
                    invertImage();
                }
            }
        });
    }

    private void invertImage() {
        Image image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        for (int i = 0; i < (int) image.getWidth(); i++) {
            for (int j = 0; j < (int) image.getHeight(); j++) {
                newImage.getPixelWriter().setColor(i, j, image.getPixelReader().getColor(i, j).invert());
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        canvasImages.addCanvasImage(newImage);
        backward.setDisable(false);
    }

    private void adjustBrightness(boolean darker) {
        Image image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        for (int i = 0; i < (int) image.getWidth(); i++) {
            for (int j = 0; j < (int) image.getHeight(); j++) {
                newImage.getPixelWriter().setColor(i, j, (darker ? image.getPixelReader().getColor(i, j).darker() : image.getPixelReader().getColor(i, j).brighter()));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        canvasImages.addCanvasImage(newImage);
        backward.setDisable(false);
    }

    private void adjustSaturate(boolean saturate) {
        Image image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        for (int i = 0; i < (int) image.getWidth(); i++) {
            for (int j = 0; j < (int) image.getHeight(); j++) {
                newImage.getPixelWriter().setColor(i, j, (saturate ? image.getPixelReader().getColor(i, j).saturate() : image.getPixelReader().getColor(i, j).desaturate()));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        canvasImages.addCanvasImage(newImage);
        backward.setDisable(false);
    }

    private void renovate() {
        if (canvasImages.getNowCanvasImage() == null) {
            try {
                if (!XMLAdminister.getImageUrl("open").equalsIgnoreCase("null")) {
                    graphicsContext.drawImage(image, 0, 0, width, height);
                } else {
                    graphicsContext.fillRect(0, 0, width, height);
                }
            } catch (Exception e) {
            }
        } else {
            graphicsContext.drawImage(canvasImages.getNowCanvasImage(), 0, 0, width, height);
        }
    }

    private boolean initImage() throws Exception {
        if (XMLAdminister.getImageUrl("open").equalsIgnoreCase("null")) {
            return false;
        } else {
            image = new Image(XMLAdminister.getImageUrl("open"));
            return true;
        }
    }

    private void initCanvas() throws Exception {
        if (initImage()) {
            canvas.setHeight(image.getHeight());
            canvas.setWidth(image.getWidth());
            width = image.getWidth();
            height = image.getHeight();
            canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
            printImage();
        } else {
            initGraphicsContext();
        }
    }

    private void initGraphicsContext() {
        width = canvas.getWidth();
        height = canvas.getHeight();
        graphicsContext = canvas.getGraphicsContext2D();
        graphicsContext.setFill(color1.getValue());
        graphicsContext.setStroke(color2.getValue());
        graphicsContext.fillRect(0, 0, width, height);
        canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
    }

    private void initColor() {
        color1.setValue(Color.WHITE);
        color2.setValue(Color.BLACK);
        color1.setBackground(new Background(new BackgroundFill(color1.getValue(), null, null)));
        color2.setBackground(new Background(new BackgroundFill(color2.getValue(), null, null)));
    }

    private void printImage() throws Exception {
        initGraphicsContext();
        graphicsContext.drawImage(image, 0, 0);
    }

    @FXML
    public void backToStart() throws IOException {
        Main.closeWindow(menuBar);
        Controller.start = false;
        Main.newWindow("../fxml/initial.fxml", "2D-Paint", 350, 500);
    }

    public void getHelp(ActionEvent actionEvent) throws IOException {
        Main.newWindow("../fxml/helpface.fxml", "help", 600, 400);
    }

    public void save() throws Exception {
        if (XMLAdminister.getImageUrl("save").equalsIgnoreCase("null")) {
            saveAs();
        } else {
            saveImage(XMLAdminister.getImageUrl("save"));
        }
    }

    public void saveAs() throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("BMP", "*.bmp"));
        File file = fileChooser.showSaveDialog((Stage) canvas.getScene().getWindow());
        if (file != null) {
            saveImage(URLDecoder.decode(file.getAbsolutePath(), "UTF-8"));
        }
    }

    private void saveImage(String url) throws IOException {
        Image image = canvas.snapshot(new SnapshotParameters(), null);
        ImageIO.write(SwingFXUtils.fromFXImage(image, null), "png", new File(url));
    }

    public void close(ActionEvent actionEvent) {
        Main.closeWindow(menuBar);
    }

    public void colorOneAction(ActionEvent actionEvent) {
        color1.setBackground(new Background(new BackgroundFill(color1.getValue(), null, null)));
        graphicsContext.setFill(color1.getValue());
    }

    public void colorTwoAction(ActionEvent actionEvent) {
        color2.setBackground(new Background(new BackgroundFill(color2.getValue(), null, null)));
        graphicsContext.setStroke(color2.getValue());
    }

    public void mouseDraggedAction(MouseEvent mouseEvent) {
        editor.addPathPoints(mouseEvent.getX(), mouseEvent.getY());
        pixelText.setText(mouseEvent.getX() + " , " + mouseEvent.getY() + " pixels");
    }

    public void mouseMovedAction(MouseEvent mouseEvent) {
        pixelText.setText(mouseEvent.getX() + " , " + mouseEvent.getY() + " pixels");
        editor.mouseMoved(mouseEvent.getX(), mouseEvent.getY());
    }

    public void mousePressedAction(MouseEvent mouseEvent) {
        renovate();
        editor.addStartPoints(mouseEvent.getX(), mouseEvent.getY());
        graphicsSizeText.setText("");
    }

    public void mouseReleasedAction(MouseEvent mouseEvent) {
        editor.addEndPoints(mouseEvent.getX(), mouseEvent.getY());
        editor.draw();
        color2.setValue((Color) graphicsContext.getStroke());
        color2.setBackground(new Background(new BackgroundFill(color2.getValue(), null, null)));
        if (editor.complete()) {
            canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
            backward.setDisable(false);
            canvasSize.setValue(canvasSize.getValue() * canvas.getHeight() / height);
            width = canvas.getWidth();
            height = canvas.getHeight();
        }
        if (editor.getContent() != null) {
            copy.setDisable(false);
            cut.setDisable(false);
            selectContent = editor.getContent();
            graphicsSizeText.setText(selectContent.getWidth() + " , " + selectContent.getHeight() + " pixels");
        } else {
            copy.setDisable(true);
            cut.setDisable(true);
            selectContent = new SelectContent();
        }
    }

    public void pasteAction(ActionEvent actionEvent) {
        if (pasteContent != null) {
            editor = new Paste(pasteContent);
            editor.setGraphicsContext(graphicsContext);
        }
    }

    public void cutAction(ActionEvent actionEvent) {
        if (selectContent.getContent() != null) {
            renovate();
            pasteContent = selectContent.getContent();
            Paint fill = graphicsContext.getFill();
            graphicsContext.setFill(Color.WHITE);
            graphicsContext.fillRect(selectContent.getUpperLeft().getX(),
                    selectContent.getUpperLeft().getY(),
                    selectContent.getWidth(),
                    selectContent.getHeight());
            graphicsContext.setFill(fill);
            canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
            paste.setDisable(false);
        }
    }

    public void copyAction(ActionEvent actionEvent) {
        if (selectContent.getContent() != null) {
            renovate();
            pasteContent = selectContent.getContent();
            paste.setDisable(false);
        }
    }

    public void hide(ActionEvent actionEvent) {
        Stage stage = (Stage) stageHide.getScene().getWindow();
        stage.setIconified(true);
    }

    public void judgeGraphics(ActionEvent actionEvent) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Button bt = (Button) actionEvent.getSource();
        editor = (Editable) Class.forName("graphics." + bt.getId()).newInstance();
        editor.setGraphicsContext(graphicsContext);
    }

    public void judgeTools(ActionEvent actionEvent) throws ClassNotFoundException, IllegalAccessException, InstantiationException {
        Button bt = (Button) actionEvent.getSource();
        editor = (Editable) Class.forName("tools." + bt.getId()).newInstance();
        editor.setGraphicsContext(graphicsContext);
    }

    public void backwardAction(ActionEvent actionEvent) throws Exception {
        if (canvasImages.isBackward()) {
            forward.setDisable(false);
            Image image = canvasImages.getBackward();
            if (image != null) {
                canvas.setWidth(image.getWidth());
                canvas.setHeight(image.getHeight());
                width = canvas.getWidth();
                height = canvas.getHeight();
                canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
                graphicsContext.drawImage(image, 0, 0);
            } else {
                if (XMLAdminister.getImageUrl("open").equalsIgnoreCase("null")) {
                    Paint fillColor = graphicsContext.getFill();
                    graphicsContext.setFill(Color.WHITE);
                    graphicsContext.fillRect(0, 0, width, height);
                    graphicsContext.setFill(fillColor);
                } else {
                    graphicsContext.drawImage(this.image, 0, 0, width, height);
                }
                backward.setDisable(true);
            }
        }
        if (!canvasImages.isBackward()) {
            backward.setDisable(true);
        }
    }

    public void forwardAction(ActionEvent actionEvent) {
        if (canvasImages.isForward()) {
            Image image = canvasImages.getForward();
            canvas.setWidth(image.getWidth());
            canvas.setHeight(image.getHeight());
            width = canvas.getWidth();
            height = canvas.getHeight();
            canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
            graphicsContext.drawImage(image, 0, 0);
            backward.setDisable(false);
        }
        if (!canvasImages.isForward()) {
            forward.setDisable(true);
        }
    }

    public void rotateLeft(ActionEvent actionEvent) {
        double width = canvas.getHeight();
        double height = canvas.getWidth();
        WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) width, (int) height);
        canvas.setWidth(width);
        canvas.setHeight(height);
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                newImage.getPixelWriter().setColor(i, j, image.getPixelReader().getColor((int) height - 1 - j, i));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        this.width = canvas.getWidth();
        this.height = canvas.getHeight();
        canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
        canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
        backward.setDisable(false);
    }

    public void rotateRight(ActionEvent actionEvent) {
        double width = canvas.getHeight();
        double height = canvas.getWidth();
        WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) width, (int) height);
        canvas.setWidth(width);
        canvas.setHeight(height);
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                newImage.getPixelWriter().setColor(i, j, image.getPixelReader().getColor(j, (int) width - i - 1));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        this.width = canvas.getWidth();
        this.height = canvas.getHeight();
        canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
        canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
        backward.setDisable(false);
    }

    public void rotateVertical(ActionEvent actionEvent) {
        WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        for (int i = 0; i < image.getWidth(); i++) {
            for (int j = 0; j < image.getHeight(); j++) {
                newImage.getPixelWriter().setColor(i, j, image.getPixelReader().getColor(i, (int) image.getHeight() - j - 1));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        this.width = canvas.getWidth();
        this.height = canvas.getHeight();
        canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
        canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
        backward.setDisable(false);
    }

    public void rotateHorizontal(ActionEvent actionEvent) {
        WritableImage image = canvas.snapshot(new SnapshotParameters(), null);
        WritableImage newImage = new WritableImage((int) image.getWidth(), (int) image.getHeight());
        for (int i = 0; i < image.getWidth(); i++) {
            for (int j = 0; j < image.getHeight(); j++) {
                newImage.getPixelWriter().setColor(i, j, image.getPixelReader().getColor((int) image.getWidth() - i - 1, j));
            }
        }
        graphicsContext.drawImage(newImage, 0, 0);
        this.width = canvas.getWidth();
        this.height = canvas.getHeight();
        canvasSizeText.setText((int) width + " , " + (int) height + "pixels");
        canvasImages.addCanvasImage(canvas.snapshot(new SnapshotParameters(), null));
        backward.setDisable(false);
    }

    public void selectAction(ActionEvent actionEvent) {
        editor = new Selector();
        editor.setGraphicsContext(graphicsContext);
    }
}