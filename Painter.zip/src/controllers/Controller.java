package controllers;

import XMLs.XMLAdminister;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import main.Main;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    /**
     * 初始化界面控制类，该类主要用于处理用户在初始化界面时所进行的操作
     */

    @FXML
    public Button btexit;
    @FXML
    public Button btnew;
    @FXML
    public Button btopen;
    @FXML
    public Button bthelp;
    @FXML
    public Pane pane;
    @FXML
    public Button close;

    protected static boolean start = false;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            XMLAdminister.setImageUrl("open", "null");
            XMLAdminister.setImageUrl("save", "null");
        } catch (Exception e) {
            System.out.println("配置文件被删除");
        }
    }

    @FXML
    public void actionOfExit() {
        Main.closeWindow(btexit);
    }


    public void newfiletext(MouseEvent mouseEvent) {
        btnew.setTooltip(new Tooltip("Create a new image file"));
    }

    public void openfiletext(MouseEvent mouseEvent) {
        btopen.setTooltip(new Tooltip("Open a existing image file"));
    }

    public void helptext(MouseEvent mouseEvent) {
        bthelp.setTooltip(new Tooltip("View help documentation"));
    }

    public void exittext(MouseEvent mouseEvent) {
        btexit.setTooltip(new Tooltip("Exit 2D-Paint"));
    }

    @FXML
    public void beginPaint() throws IOException {
        start = true;
        Main.closeWindow(btnew);
        Main.newWindow("../fxml/paintface.fxml", "2D-Paint", 1500, 1010);
    }

    public void newFile(ActionEvent actionEvent) throws Exception {
        XMLAdminister.setImageUrl("open", "null");
        beginPaint();
    }

    public void openFile(ActionEvent actionEvent) throws Exception {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialDirectory(new File("C:\\"));
        fileChooser.setTitle("Open a existing image file");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("ALL", "*.jpg;*.bmp;*.jfif"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("BMP", "*.bmp"),
                new FileChooser.ExtensionFilter("JFIF", "*.jfif"));
        File file = fileChooser.showOpenDialog(btopen.getScene().getWindow());
        if (file != null) {
            String url = URLDecoder.decode(file.getAbsoluteFile().toURL().toString(), "UTF-8");
            XMLAdminister.setImageUrl("open", url);
            XMLAdminister.setImageUrl("save", URLDecoder.decode(file.getAbsolutePath(), "UTF-8"));
            beginPaint();
        }
    }

    public void helpAction(ActionEvent actionEvent) throws IOException {
        Main.closeWindow(bthelp);
        Main.newWindow("../fxml/helpface.fxml", "help", 600, 400);
    }

    public void closeHelp(ActionEvent actionEvent) throws IOException {
        Main.closeWindow(close);
        if (! start) {
            Main.newWindow("../fxml/initial.fxml", "2D-Paint", 350, 500);
        }
    }
}