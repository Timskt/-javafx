package XMLs;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class XMLAdminister {
    private static File file = new File("src/XMLs/image_url.xml");

    public static String getImageUrl(String id) throws Exception {
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = documentBuilder.parse(file);
        Element root = doc.getDocumentElement();
        NodeList images = root.getElementsByTagName("image");
        for (int i = 0; i < images.getLength(); i++) {
            Node node = images.item(i);
            Element image = (Element) node;
            if (image.getAttribute("id").equalsIgnoreCase(id)) {
                return image.getElementsByTagName("url").item(0).getTextContent();
            }
        }
        return null;
    }

    public static void setImageUrl(String id, String url) throws Exception {
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document doc = documentBuilder.parse(file);
        Element root = doc.getDocumentElement();
        NodeList images = root.getElementsByTagName("image");
        for (int i = 0; i < images.getLength(); i++) {
            Node node = images.item(i);
            Element image = (Element) node;
            if (image.getAttribute("id").equalsIgnoreCase(id)) {
                image.getElementsByTagName("url").item(0).setTextContent(url);
            }
        }
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        Source source = new DOMSource(doc);
        Result result = new StreamResult(file);
        transformer.transform(source, result);
    }
}
